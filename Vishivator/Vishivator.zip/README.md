# OrnamentGenerator

Ornament generator by the entered word.

Examples:

![Марина](https://goo.gl/A3p6AH)

![Арсен](https://goo.gl/UjEKzo)

![Володимир](https://goo.gl/X42OG8)

![Святослав](https://goo.gl/1UMUyE)

![Єва](https://goo.gl/lBgACG)
